import { GoogleGenAI, Type, Modality, GenerateContentResponse } from "@google/genai";
import { Language, GenerationMode, GroundingSource } from "../types";

const getAIClient = () => new GoogleGenAI({ apiKey: process.env.API_KEY });

export interface FileData {
  data: string;
  mimeType: string;
  name: string;
}

const getLanguageName = (lang: Language) => {
  const mapping = {
    [Language.EN]: 'English',
    [Language.ES]: 'Spanish',
    [Language.FR]: 'French',
    [Language.DE]: 'German',
    [Language.ZH]: 'Chinese',
    [Language.JA]: 'Japanese'
  };
  return mapping[lang] || 'English';
};

const getBaseInstruction = (prompt: string, history: string, isImage: boolean, file: boolean, langName: string, mode: GenerationMode) => {
  let baseInstruction = `Output your response exclusively in ${langName}. `;
  const branchingInstruction = `\n\nAt the very end of your response, strictly include a section titled "[PATHS]" followed by exactly three bullet points (short sentences) of potential narrative directions the user could take next.`;

  if (mode === GenerationMode.SONG) {
    baseInstruction += `You are a world-class songwriter and lyricist. Compose an evocative song with a clear structure (e.g., [Verse 1], [Chorus], [Verse 2], [Outro]). 
    Max 300 words. ${isImage ? "Inspired by this image." : ""} ${prompt ? `Theme: ${prompt}` : ""}` + branchingInstruction;
  } else {
    if (isImage) {
      baseInstruction += `Analyze this image and ${prompt ? `based on the context "${prompt}", ` : ""}create a cinematic narrative (max 300 words). Focus on sensory details.` + branchingInstruction;
    } else if (file) {
      baseInstruction += `Analyze this document and ${prompt ? prompt : "summarize its essence into a compelling narrative."} Max 350 words.` + branchingInstruction;
    } else {
      baseInstruction += history 
        ? `Establishment: ${history}\n\nEvolution: ${prompt}\n\nContinue this story. Max 300 words.` + branchingInstruction
        : `Manifest this concept into a vivid narrative (max 300 words): ${prompt}` + branchingInstruction;
    }
  }
  return baseInstruction;
};

export const imagineScenarioStream = async (
  prompt: string, 
  history: string = "", 
  file?: FileData, 
  lang: Language = Language.EN, 
  mode: GenerationMode = GenerationMode.STORY,
  coords?: { lat: number, lng: number },
  onChunk?: (text: string) => void
) => {
  const ai = getAIClient();
  const langName = getLanguageName(lang);
  const isImage = file?.mimeType.startsWith('image/');
  
  const baseInstruction = getBaseInstruction(prompt, history, isImage, !!file, langName, mode);

  let contents: any;
  if (file) {
    contents = {
      parts: [
        { inlineData: { data: file.data, mimeType: file.mimeType } },
        { text: baseInstruction }
      ]
    };
  } else {
    contents = { parts: [{ text: baseInstruction }] };
  }

  const response = await ai.models.generateContentStream({
    model: 'gemini-3-flash-preview',
    contents,
    config: {
      tools: [{ googleSearch: {} }]
    }
  });

  let fullText = "";
  let lastChunk: GenerateContentResponse | null = null;

  for await (const chunk of response) {
    const text = chunk.text;
    if (text) {
      fullText += text;
      const displayPart = fullText.split('[PATHS]')[0];
      if (onChunk) onChunk(displayPart);
    }
    lastChunk = chunk;
  }

  const parts = fullText.split('[PATHS]');
  const story = parts[0].trim();
  const pathsText = parts[1] || "";
  const neuralPaths = pathsText.split('\n').map(p => p.replace(/^[*-]\s*/, '').trim()).filter(p => p.length > 0).slice(0, 3);

  const groundingChunks = lastChunk?.candidates?.[0]?.groundingMetadata?.groundingChunks || [];
  const sources: GroundingSource[] = groundingChunks
    .map((chunk: any) => {
      if (chunk.web) return { title: chunk.web.title || 'Source', uri: chunk.web.uri || '#' };
      return null;
    })
    .filter((s): s is GroundingSource => s !== null);

  return { story, sources, neuralPaths };
};

export const generateVisual = async (story: string) => {
  const ai = getAIClient();
  const response = await ai.models.generateContent({
    model: 'gemini-2.5-flash-image',
    contents: {
      parts: [
        { text: `A cinematic wide shot visualizing this story: ${story.substring(0, 800)}. Style: High-detail concept art, volumetric lighting, dramatic composition.` }
      ]
    },
    config: {
      imageConfig: { aspectRatio: "16:9" }
    }
  });

  const part = response.candidates?.[0]?.content?.parts.find(p => p.inlineData);
  return part ? `data:image/png;base64,${part.inlineData.data}` : null;
};

export const generateVideo = async (prompt: string, imageBase64?: string) => {
  const ai = getAIClient();
  const generationParams: any = {
    model: 'veo-3.1-fast-generate-preview',
    prompt: `Cinematic motion: ${prompt.substring(0, 500)}`,
    config: {
      numberOfVideos: 1,
      resolution: '720p',
      aspectRatio: '16:9'
    }
  };

  if (imageBase64) {
    generationParams.image = {
      imageBytes: imageBase64.split(',')[1],
      mimeType: 'image/png'
    };
  }

  let operation = await ai.models.generateVideos(generationParams);
  
  while (!operation.done) {
    await new Promise(resolve => setTimeout(resolve, 10000));
    operation = await ai.operations.getVideosOperation({ operation: operation });
  }

  const downloadLink = operation.response?.generatedVideos?.[0]?.video?.uri;
  if (!downloadLink) return null;
  
  const videoResponse = await fetch(`${downloadLink}&key=${process.env.API_KEY}`);
  const blob = await videoResponse.blob();
  return URL.createObjectURL(blob);
};

export const narrateStory = async (text: string, lang: Language = Language.EN, mode: GenerationMode = GenerationMode.STORY, dualSpeaker: boolean = false) => {
  const ai = getAIClient();
  
  let instruction = mode === GenerationMode.SONG
    ? `Sing these lyrics: ${text}`
    : `Narrate this story: ${text}`;

  const config: any = {
    responseModalities: [Modality.AUDIO],
  };

  if (dualSpeaker) {
    config.speechConfig = {
      multiSpeakerVoiceConfig: {
        speakerVoiceConfigs: [
          { speaker: 'Alpha', voiceConfig: { prebuiltVoiceConfig: { voiceName: 'Kore' } } },
          { speaker: 'Beta', voiceConfig: { prebuiltVoiceConfig: { voiceName: 'Puck' } } }
        ]
      }
    };
  } else {
    config.speechConfig = {
      voiceConfig: { prebuiltVoiceConfig: { voiceName: 'Charon' } }
    };
  }

  const response = await ai.models.generateContent({
    model: "gemini-2.5-flash-preview-tts",
    contents: [{ parts: [{ text: instruction }] }],
    config
  });

  return response.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data || null;
};

export function decodeBase64ToBytes(base64: string): Uint8Array {
  const binaryString = atob(base64);
  const bytes = new Uint8Array(binaryString.length);
  for (let i = 0; i < binaryString.length; i++) {
    bytes[i] = binaryString.charCodeAt(i);
  }
  return bytes;
}

export async function decodeAudioData(
  data: Uint8Array,
  ctx: AudioContext,
  sampleRate: number = 24000,
  numChannels: number = 1
): Promise<AudioBuffer> {
  const dataInt16 = new Int16Array(data.buffer);
  const frameCount = dataInt16.length / numChannels;
  const buffer = ctx.createBuffer(numChannels, frameCount, sampleRate);

  for (let channel = 0; channel < numChannels; channel++) {
    const channelData = buffer.getChannelData(channel);
    for (let i = 0; i < frameCount; i++) {
      channelData[i] = dataInt16[i * numChannels + channel] / 32768.0;
    }
  }
  return buffer;
}