
import React from 'react';
import { AppMode, Language } from '../types';
import { translations } from '../constants/translations';

interface SidebarProps {
  currentMode: AppMode;
  setMode: (mode: AppMode) => void;
  language: Language;
  setLanguage: (lang: Language) => void;
  onClose?: () => void;
}

const Sidebar: React.FC<SidebarProps> = ({ currentMode, setMode, language, setLanguage, onClose }) => {
  const t = translations[language];

  const primaryNav = [
    { id: AppMode.IMAGINE, icon: 'fa-wand-magic-sparkles', label: t.imagine },
    { id: AppMode.GALLERY, icon: 'fa-bolt-lightning', label: t.vault },
  ];

  const secondaryNav = [
    { id: AppMode.ABOUT, icon: 'fa-circle-info', label: t.about },
    { id: AppMode.TERMS, icon: 'fa-scale-balanced', label: t.terms },
    { id: AppMode.PRIVACY, icon: 'fa-shield-halved', label: t.privacy },
    { id: AppMode.CONTACT, icon: 'fa-envelope', label: t.contact },
  ];

  const handleNavClick = (id: AppMode) => {
    setMode(id);
    if (onClose) onClose();
  };

  return (
    <aside className="w-full h-full flex flex-col glass border-r border-white/5 overflow-y-auto overflow-x-hidden pt-[env(safe-area-inset-top)] pb-[env(safe-area-inset-bottom)]">
      <div className="p-8 flex items-center justify-between gap-4 group shrink-0">
        <div className="flex items-center gap-4 cursor-pointer" onClick={() => handleNavClick(AppMode.IMAGINE)}>
          <div className="relative w-12 h-12 md:w-16 md:h-16 flex items-center justify-center shrink-0">
              {/* Outer Deep Charcoal Shell */}
              <div className="absolute inset-0 bg-[#0c0e14] rounded-2xl shadow-2xl border border-white/5 group-hover:scale-105 transition-transform duration-500"></div>
              
              {/* Nebula Glow Background */}
              <div className="absolute inset-1 bg-gradient-to-br from-indigo-950 via-purple-950 to-gray-950 rounded-[14px] overflow-hidden">
                <div className="absolute -top-4 -right-4 w-12 h-12 bg-purple-600/20 blur-xl rounded-full"></div>
                <div className="absolute -bottom-4 -left-4 w-12 h-12 bg-indigo-600/20 blur-xl rounded-full"></div>
              </div>

              {/* The 3D Brain & X SVG */}
              <div className="relative z-10 w-full h-full p-1.5 flex items-center justify-center">
                <svg viewBox="0 0 100 100" className="w-full h-full drop-shadow-[0_0_8px_rgba(99,102,241,0.3)]">
                  <defs>
                    <linearGradient id="metalX" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="0%" stopColor="#ffffff" />
                      <stop offset="50%" stopColor="#94a3b8" />
                      <stop offset="100%" stopColor="#475569" />
                    </linearGradient>
                    <radialGradient id="brainCore">
                      <stop offset="0%" stopColor="#4f46e5" stopOpacity="0.8" />
                      <stop offset="100%" stopColor="#1e1b4b" stopOpacity="0.4" />
                    </radialGradient>
                  </defs>
                  
                  {/* Stylized Brain Outlines */}
                  <path d="M50 20 C25 20 15 35 15 50 C15 65 25 80 50 80 C75 80 85 65 85 50 C85 35 75 20 50 20" fill="url(#brainCore)" stroke="#6366f1" strokeWidth="0.5" strokeOpacity="0.3" />
                  
                  {/* Internal Neural Pathways (Glowing Synapses) */}
                  <circle cx="35" cy="40" r="1" fill="#ec4899" className="animate-pulse">
                    <animate attributeName="r" values="0.5;1.5;0.5" dur="2s" repeatCount="indefinite" />
                  </circle>
                  <circle cx="65" cy="60" r="0.8" fill="#ec4899" className="animate-pulse" />
                  <circle cx="50" cy="35" r="1.2" fill="#ec4899" />
                  <path d="M35 40 Q50 35 65 60" stroke="#ec4899" strokeWidth="0.2" strokeOpacity="0.4" fill="none" />

                  {/* Metallic Italicized X */}
                  <g transform="translate(15, 25) scale(0.7) skewX(-10)">
                     <path d="M0 0 L30 0 L100 100 L70 100 Z" fill="url(#metalX)" />
                     <path d="M100 0 L70 0 L0 100 L30 100 Z" fill="url(#metalX)" />
                     {/* Highlights on X */}
                     <path d="M0 0 L30 0 L35 5 L5 5 Z" fill="white" fillOpacity="0.3" />
                     <path d="M70 95 L100 95 L95 100 L65 100 Z" fill="black" fillOpacity="0.2" />
                  </g>
                </svg>
              </div>
          </div>
          <div className="flex flex-col">
            <span className="font-heading font-black text-lg md:text-xl tracking-tighter text-white uppercase leading-none">Imagine X</span>
            <span className="text-[7px] text-gray-600 font-bold tracking-[0.4em] uppercase">{t.neuralHub}</span>
          </div>
        </div>

        {onClose && (
          <button onClick={onClose} className="w-10 h-10 rounded-xl bg-white/5 flex items-center justify-center text-gray-500 hover:text-white transition-all active:scale-90">
            <i className="fa-solid fa-chevron-left"></i>
          </button>
        )}
      </div>

      <nav className="flex-1 px-4 py-4 space-y-1">
        <div className="text-[10px] text-gray-600 font-black uppercase tracking-[0.3em] mb-4 ml-4 text-left">{t.core}</div>
        {primaryNav.map((item) => (
          <button
            key={item.id}
            onClick={() => handleNavClick(item.id)}
            className={`w-full flex items-center gap-4 px-5 py-4 rounded-2xl transition-all duration-300 active:scale-95 ${
              currentMode === item.id 
                ? 'bg-indigo-600/20 text-indigo-400 border border-indigo-500/30 shadow-[0_0_20px_rgba(99,102,241,0.05)]' 
                : 'text-gray-500 hover:bg-white/5 hover:text-gray-200'
            }`}
          >
            <i className={`fa-solid ${item.icon} text-lg w-6 flex justify-center`}></i>
            <span className="font-bold tracking-tight uppercase text-xs">{item.label}</span>
          </button>
        ))}

        <div className="text-[10px] text-gray-600 font-black uppercase tracking-[0.3em] mb-4 mt-8 ml-4 text-left">{t.identity}</div>
        {secondaryNav.map((item) => (
          <button
            key={item.id}
            onClick={() => handleNavClick(item.id)}
            className={`w-full flex items-center gap-4 px-5 py-3 rounded-2xl transition-all duration-300 active:scale-95 ${
              currentMode === item.id 
                ? 'bg-purple-600/20 text-purple-400 border border-purple-500/30' 
                : 'text-gray-500 hover:bg-white/5 hover:text-gray-200'
            }`}
          >
            <i className={`fa-solid ${item.icon} text-base w-6 flex justify-center`}></i>
            <span className="font-medium text-xs uppercase tracking-wide">{item.label}</span>
          </button>
        ))}

        <div className="pt-8 px-4">
          <div className="text-[10px] text-gray-600 font-black uppercase tracking-[0.3em] mb-4 text-left">Language</div>
          <div className="grid grid-cols-3 gap-2">
            {[
              { code: Language.EN, label: 'EN' },
              { code: Language.ES, label: 'ES' },
              { code: Language.FR, label: 'FR' },
              { code: Language.DE, label: 'DE' },
              { code: Language.ZH, label: 'ZH' },
              { code: Language.JA, label: 'JA' },
            ].map((lang) => (
              <button
                key={lang.code}
                onClick={() => setLanguage(lang.code)}
                className={`py-2 rounded-lg text-[10px] font-bold transition-all border ${
                  language === lang.code 
                    ? 'bg-indigo-600/20 border-indigo-500/50 text-indigo-400' 
                    : 'bg-white/5 border-transparent text-gray-500 hover:bg-white/10'
                }`}
              >
                {lang.label}
              </button>
            ))}
          </div>
        </div>
      </nav>

      <div className="p-6 border-t border-white/5 shrink-0">
        <div className="glass rounded-[1.5rem] p-5 text-[9px] text-gray-600 font-bold tracking-[0.2em] uppercase space-y-3">
          <div className="flex justify-between items-center">
            <span className="text-gray-500">{t.systemLink}</span>
            <div className="flex items-center gap-2">
               <span className="w-1.5 h-1.5 rounded-full bg-green-500 animate-pulse"></span>
               <span className="text-indigo-400">{t.stable}</span>
            </div>
          </div>
          <div className="flex gap-1 h-1.5">
            <div className="flex-1 bg-indigo-500/40 rounded-full"></div>
            <div className="flex-1 bg-indigo-500/20 rounded-full"></div>
            <div className="flex-1 bg-indigo-500/10 rounded-full"></div>
          </div>
        </div>
      </div>
    </aside>
  );
};

export default Sidebar;
