
import React, { useState } from 'react';
import { ImaginationResult, Language } from '../types';
import { translations } from '../constants/translations';

interface GalleryViewProps {
  items: ImaginationResult[];
  onDelete: (id: string) => void;
  language: Language;
}

const GalleryView: React.FC<GalleryViewProps> = ({ items, onDelete, language }) => {
  const [searchQuery, setSearchQuery] = useState('');
  const t = translations[language];

  const filteredItems = items.filter(item => 
    item.prompt.toLowerCase().includes(searchQuery.toLowerCase()) || 
    item.story.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="max-w-7xl mx-auto space-y-8 animate-in fade-in duration-500 px-4 pb-20">
      <header className="flex flex-col md:flex-row justify-between items-start md:items-end border-b border-white/5 pb-8 gap-6">
        <div className="space-y-2">
          <h2 className="text-3xl font-heading font-bold">{t.chronicles.split(' ')[0]} <span className="text-indigo-400">{t.chronicles.split(' ').slice(1).join(' ')}</span></h2>
          <p className="text-gray-500">Saved fragments of your imagination.</p>
        </div>
        
        <div className="flex flex-col md:flex-row items-stretch md:items-center gap-4 w-full md:w-auto">
          <div className="relative w-full md:w-72">
            <i className="fa-solid fa-magnifying-glass absolute left-4 top-1/2 -translate-y-1/2 text-gray-600 text-xs"></i>
            <input 
              type="text" 
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder={t.searchChronicles}
              className="w-full bg-white/5 border border-white/5 rounded-xl py-3 pl-10 pr-4 text-xs focus:ring-1 focus:ring-indigo-500 outline-none transition-all"
            />
          </div>
          <div className="text-gray-600 text-[10px] font-bold uppercase tracking-widest bg-white/5 px-4 py-3 rounded-xl border border-white/5 shrink-0 text-center">
            {filteredItems.length} {t.artifacts}
          </div>
        </div>
      </header>

      {items.length === 0 ? (
        <div className="py-32 text-center space-y-4">
          <div className="w-20 h-20 bg-white/5 rounded-full flex items-center justify-center mx-auto text-gray-700">
            <i className="fa-solid fa-box-open text-3xl"></i>
          </div>
          <p className="text-gray-500">{t.emptyVault}</p>
        </div>
      ) : filteredItems.length === 0 ? (
        <div className="py-32 text-center space-y-4">
          <p className="text-gray-500">No matching chronicles found.</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
          {filteredItems.map((item) => (
            <div key={item.id} className="group relative glass rounded-2xl overflow-hidden hover:border-indigo-500/30 transition-all flex flex-col">
              <div className="aspect-video relative overflow-hidden bg-gray-900">
                {item.imageUrl ? (
                  <img src={item.imageUrl} alt={item.prompt} className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700" />
                ) : (
                  <div className="w-full h-full flex items-center justify-center">
                    <i className="fa-solid fa-image text-white/10 text-4xl"></i>
                  </div>
                )}
                <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity p-4 flex items-end">
                   <button 
                    onClick={() => onDelete(item.id)}
                    aria-label="Delete chronicle"
                    className="ml-auto w-8 h-8 rounded-lg bg-red-500/20 text-red-400 hover:bg-red-500 hover:text-white transition-all flex items-center justify-center"
                   >
                     <i className="fa-solid fa-trash text-sm"></i>
                   </button>
                </div>
                {item.videoUrl && (
                  <div className="absolute top-4 right-4 w-7 h-7 rounded-full bg-indigo-500 flex items-center justify-center shadow-lg">
                    <i className="fa-solid fa-video text-[10px] text-white"></i>
                  </div>
                )}
              </div>
              <div className="p-5 space-y-3 flex-1">
                <p className="text-[10px] font-bold text-indigo-400 uppercase tracking-widest">
                  {new Date(item.timestamp).toLocaleDateString()}
                </p>
                <h4 className="font-heading font-semibold text-lg line-clamp-1 text-gray-100">{item.prompt}</h4>
                <p className="text-gray-400 text-sm line-clamp-3 italic">"{item.story}"</p>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default GalleryView;
