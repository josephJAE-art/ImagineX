
import React from 'react';
import { Language } from '../types';
import { translations } from '../constants/translations';

interface AboutViewProps {
  language: Language;
}

const AboutView: React.FC<AboutViewProps> = ({ language }) => {
  const t = translations[language];

  return (
    <div className="max-w-5xl mx-auto space-y-24 py-12 md:py-20 animate-in slide-in-from-right-12 duration-700 px-6 pb-32">
      {/* 1. THE MISSION: WHAT IT DOES */}
      <header className="space-y-8">
        <div className="inline-flex items-center gap-3 px-4 py-1.5 rounded-full border border-indigo-500/30 bg-indigo-500/10 text-indigo-400 text-[10px] font-black uppercase tracking-[0.4em]">
          <span className="relative flex h-2 w-2">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-indigo-400 opacity-75"></span>
            <span className="relative inline-flex rounded-full h-2 w-2 bg-indigo-500"></span>
          </span>
          The Creative Protocol
        </div>
        <h1 className="text-6xl md:text-9xl font-heading font-black tracking-tighter uppercase leading-[0.85] text-white">
          WHAT IS <br/><span className="gradient-text">IMAGINE X?</span>
        </h1>
        <p className="text-xl md:text-2xl text-gray-400 font-light leading-relaxed max-w-3xl">
          Imagine X is an autonomous multimodal studio designed to collapse the distance between abstract thought and high-fidelity reality. It transforms single seeds of intent—text, images, or documents—into complete, living sensory artifacts.
        </p>
      </header>

      {/* 2. ARCHITECTURE: HOW IT WORKS */}
      <section className="space-y-12">
        <div className="flex items-center gap-6">
          <h2 className="text-2xl md:text-3xl font-heading font-bold uppercase tracking-tight text-white">The Neural Architecture</h2>
          <div className="h-px flex-1 bg-gradient-to-r from-white/10 to-transparent"></div>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="glass p-10 rounded-[2.5rem] space-y-6 group hover:border-indigo-500/40 transition-all duration-500">
            <div className="w-12 h-12 rounded-2xl bg-indigo-500/10 flex items-center justify-center text-indigo-400 font-black text-xl group-hover:scale-110 transition-transform">01</div>
            <div className="space-y-3">
              <h4 className="font-bold text-lg uppercase tracking-tight text-white">Ingestion</h4>
              <p className="text-gray-500 text-sm leading-relaxed">Leveraging the vast context window of Gemini 3, iMX analyzes complex documents and visual signals to extract deep narrative potential.</p>
            </div>
          </div>
          <div className="glass p-10 rounded-[2.5rem] space-y-6 group hover:border-purple-500/40 transition-all duration-500">
            <div className="w-12 h-12 rounded-2xl bg-purple-500/10 flex items-center justify-center text-purple-400 font-black text-xl group-hover:scale-110 transition-transform">02</div>
            <div className="space-y-3">
              <h4 className="font-bold text-lg uppercase tracking-tight text-white">Synthesis</h4>
              <p className="text-gray-500 text-sm leading-relaxed">The engine performs cross-modal synthesis, generating cinematic scripts, song structures, and high-fidelity visual prompts simultaneously.</p>
            </div>
          </div>
          <div className="glass p-10 rounded-[2.5rem] space-y-6 group hover:border-pink-500/40 transition-all duration-500">
            <div className="w-12 h-12 rounded-2xl bg-pink-500/10 flex items-center justify-center text-pink-400 font-black text-xl group-hover:scale-110 transition-transform">03</div>
            <div className="space-y-3">
              <h4 className="font-bold text-lg uppercase tracking-tight text-white">Manifestation</h4>
              <p className="text-gray-500 text-sm leading-relaxed">Thoughts manifest into four distinct artifacts: a narrative text, a concept image, cinematic video motion, and a soulful audio performance.</p>
            </div>
          </div>
        </div>
      </section>

      {/* 3. OPERATIONAL MANUAL: HOW TO USE */}
      <section className="relative glass rounded-[3rem] p-10 md:p-20 overflow-hidden border-indigo-500/10">
        <div className="absolute top-0 right-0 w-[400px] h-[400px] bg-indigo-600/10 blur-[120px] -mr-48 -mt-48 rounded-full"></div>
        <div className="absolute bottom-0 left-0 w-[300px] h-[300px] bg-purple-600/5 blur-[100px] -ml-32 -mb-32 rounded-full"></div>
        
        <div className="relative z-10 space-y-16">
          <div className="text-center space-y-4">
            <h2 className="text-4xl md:text-5xl font-heading font-black uppercase tracking-tighter text-white">How to Operate</h2>
            <p className="text-gray-500 uppercase text-[10px] tracking-[0.4em] font-bold">Standard iMX Deployment Sequence</p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-4 gap-12">
            {[
              { icon: 'fa-keyboard', title: 'Seed', desc: 'Provide a theme or upload a visual context (Image/Doc).' },
              { icon: 'fa-sliders', title: 'Calibrate', desc: 'Select Story or Song mode. Toggle Dual-Voice protocols.' },
              { icon: 'fa-bolt-lightning', title: 'Execute', desc: 'Initialize the synthesis. The Core will weave your artifacts.' },
              { icon: 'fa-diagram-project', title: 'Branch', desc: 'Explore Neural Paths to extend the imagination loop.' },
            ].map((step, i) => (
              <div key={i} className="text-center space-y-6">
                <div className="w-16 h-16 rounded-[1.5rem] bg-white/5 border border-white/10 flex items-center justify-center mx-auto text-indigo-400 text-2xl shadow-xl shadow-black/50">
                  <i className={`fa-solid ${step.icon}`}></i>
                </div>
                <div className="space-y-2">
                  <h4 className="font-bold uppercase text-xs tracking-[0.3em] text-white">{step.title}</h4>
                  <p className="text-gray-500 text-xs leading-relaxed">{step.desc}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* 4. FEATURE DEEP-DIVE */}
      <section className="space-y-16">
        <div className="text-center space-y-4">
          <h2 className="text-4xl md:text-6xl font-heading font-black uppercase tracking-tighter text-white">System Features</h2>
          <div className="h-1 w-20 bg-indigo-500 mx-auto rounded-full"></div>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-x-12 gap-y-16">
          <div className="flex gap-8 group">
            <div className="shrink-0 w-16 h-16 rounded-2xl bg-indigo-500/10 flex items-center justify-center text-indigo-400 border border-indigo-500/20 group-hover:bg-indigo-500 group-hover:text-white transition-all duration-700">
              <i className="fa-solid fa-music text-2xl"></i>
            </div>
            <div className="space-y-3">
              <h4 className="font-bold uppercase tracking-[0.2em] text-[11px] text-white">Rhythmic Composition</h4>
              <p className="text-gray-500 text-sm leading-relaxed">Beyond stories, Imagine X acts as a world-class lyricist. Song Mode uses melodic weights to ensure rhyming, cadence, and evocative songwriting flow.</p>
            </div>
          </div>

          <div className="flex gap-8 group">
            <div className="shrink-0 w-16 h-16 rounded-2xl bg-purple-500/10 flex items-center justify-center text-purple-400 border border-purple-500/20 group-hover:bg-purple-500 group-hover:text-white transition-all duration-700">
              <i className="fa-solid fa-map-location-dot text-2xl"></i>
            </div>
            <div className="space-y-3">
              <h4 className="font-bold uppercase tracking-[0.2em] text-[11px] text-white">Neural Grounding</h4>
              <p className="text-gray-500 text-sm leading-relaxed">Anchored in reality. Integrated with Google Search and Maps, the engine can verify locations and cite sources for historical or geographical narratives.</p>
            </div>
          </div>

          <div className="flex gap-8 group">
            <div className="shrink-0 w-16 h-16 rounded-2xl bg-pink-500/10 flex items-center justify-center text-pink-400 border border-pink-500/20 group-hover:bg-pink-500 group-hover:text-white transition-all duration-700">
              <i className="fa-solid fa-clapperboard text-2xl"></i>
            </div>
            <div className="space-y-3">
              <h4 className="font-bold uppercase tracking-[0.2em] text-[11px] text-white">Veo Cinema (v3)</h4>
              <p className="text-gray-500 text-sm leading-relaxed">Synthesize high-fidelity video loops. Imagine X transforms static concept art into cinematic motion, capturing light and physics with breathtaking accuracy.</p>
            </div>
          </div>

          <div className="flex gap-8 group">
            <div className="shrink-0 w-16 h-16 rounded-2xl bg-amber-500/10 flex items-center justify-center text-amber-400 border border-amber-500/20 group-hover:bg-amber-500 group-hover:text-white transition-all duration-700">
              <i className="fa-solid fa-microphone-lines text-2xl"></i>
            </div>
            <div className="space-y-3">
              <h4 className="font-bold uppercase tracking-[0.2em] text-[11px] text-white">Dual-Voice Protocol</h4>
              <p className="text-gray-500 text-sm leading-relaxed">Toggle Dual Voice Mode to turn narratives into acted dialogues. Two distinct voices (Alpha & Beta) perform your content with emotional range.</p>
            </div>
          </div>
        </div>
      </section>

      {/* 5. WHY IMAGINE X? */}
      <section className="py-20 border-y border-white/5 grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
        <div className="space-y-10">
          <h3 className="text-4xl md:text-5xl font-heading font-bold uppercase tracking-tighter text-white leading-tight">
            Why Choose <span className="text-indigo-500 italic">Imagine X?</span>
          </h3>
          <div className="space-y-8">
            <div className="flex items-start gap-6 group">
              <div className="w-10 h-10 rounded-full bg-indigo-500/10 flex items-center justify-center text-indigo-400 shrink-0 group-hover:bg-indigo-500 group-hover:text-white transition-colors">
                <i className="fa-solid fa-vault"></i>
              </div>
              <div className="space-y-1">
                <h5 className="font-bold text-white text-sm uppercase tracking-widest">Privacy-First Vault</h5>
                <p className="text-gray-500 text-sm leading-relaxed">Your collection stays yours. We use local IndexedDB storage, meaning your imagination is stored in your private "Vault", not on our servers.</p>
              </div>
            </div>
            <div className="flex items-start gap-6 group">
              <div className="w-10 h-10 rounded-full bg-purple-500/10 flex items-center justify-center text-purple-400 shrink-0 group-hover:bg-purple-500 group-hover:text-white transition-colors">
                <i className="fa-solid fa-infinity"></i>
              </div>
              <div className="space-y-1">
                <h5 className="font-bold text-white text-sm uppercase tracking-widest">Endless Branching</h5>
                <p className="text-gray-500 text-sm leading-relaxed">Narratives never end. Each process generates "Neural Paths"—mini-choices that allow you to guide the story into infinite variations.</p>
              </div>
            </div>
            <div className="flex items-start gap-6 group">
              <div className="w-10 h-10 rounded-full bg-pink-500/10 flex items-center justify-center text-pink-400 shrink-0 group-hover:bg-pink-500 group-hover:text-white transition-colors">
                <i className="fa-solid fa-brain"></i>
              </div>
              <div className="space-y-1">
                <h5 className="font-bold text-white text-sm uppercase tracking-widest">High-Reasoning Synthesis</h5>
                <p className="text-gray-500 text-sm leading-relaxed">Unlike simple chat bots, iMX uses Gemini 3 Pro reasoning to ensure every story and song is conceptually deep and logically consistent.</p>
              </div>
            </div>
          </div>
        </div>
        
        <div className="relative">
           <div className="absolute -inset-10 bg-indigo-600/10 blur-[120px] rounded-full"></div>
           <div className="relative glass p-12 md:p-16 rounded-[3rem] border-white/10 text-center space-y-8 overflow-hidden">
              <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-transparent via-indigo-500 to-transparent opacity-40"></div>
              <div className="space-y-2">
                <div className="text-7xl font-black gradient-text">2025</div>
                <div className="text-[10px] font-black uppercase tracking-[0.4em] text-gray-500">The New Creative Epoch</div>
              </div>
              <div className="h-px bg-white/5 w-1/2 mx-auto"></div>
              <p className="text-gray-300 text-sm md:text-base italic leading-relaxed font-light">
                "Imagine X isn't just a tool; it's a co-creator. It bridges the synaptic gap between abstract inspiration and high-fidelity artifact."
              </p>
              <div className="pt-4 flex justify-center gap-2">
                {[...Array(5)].map((_, i) => (
                  <div key={i} className="w-1 h-1 rounded-full bg-indigo-500/40"></div>
                ))}
              </div>
           </div>
        </div>
      </section>

      <footer className="pt-24 text-center space-y-4 opacity-50">
        <div className="text-gray-500 text-[10px] font-black uppercase tracking-[0.4em]">
          Protocol iMX v2.5.0 • Powered by Google Gemini 3 • Created by Joseph Mwango
        </div>
      </footer>
    </div>
  );
};

export default AboutView;
