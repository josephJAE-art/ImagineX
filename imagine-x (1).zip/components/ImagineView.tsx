import React, { useState, useRef, useEffect } from 'react';
import { 
  imagineScenarioStream, 
  generateVisual, 
  generateVideo,
  narrateStory, 
  decodeBase64ToBytes, 
  decodeAudioData,
  FileData
} from '../services/geminiService';
import { ImaginationResult, Language, GenerationMode } from '../types';
import { translations } from '../constants/translations';

interface ImagineViewProps {
  onSave: (result: ImaginationResult) => void;
  language: Language;
}

const ImagineView: React.FC<ImagineViewProps> = ({ onSave, language }) => {
  const [prompt, setPrompt] = useState('');
  const [followUpPrompt, setFollowUpPrompt] = useState('');
  const [loading, setLoading] = useState(false);
  const [videoLoading, setVideoLoading] = useState(false);
  const [status, setStatus] = useState('');
  const [streamingStory, setStreamingStory] = useState('');
  const [result, setResult] = useState<ImaginationResult | null>(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [selectedFile, setSelectedFile] = useState<FileData | null>(null);
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);
  const [genMode, setGenMode] = useState<GenerationMode>(GenerationMode.STORY);
  const [dualSpeaker, setDualSpeaker] = useState(false);
  const [hasVeoKey, setHasVeoKey] = useState(false);
  
  const audioContextRef = useRef<AudioContext | null>(null);
  const sourceRef = useRef<AudioBufferSourceNode | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const statusIntervalRef = useRef<number | null>(null);

  const t = translations[language];

  useEffect(() => {
    const checkVeo = async () => {
      if ((window as any).aistudio?.hasSelectedApiKey) {
        const hasKey = await (window as any).aistudio.hasSelectedApiKey();
        setHasVeoKey(hasKey);
      }
    };
    checkVeo();
    return () => stopReassuringLoading();
  }, []);

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = () => {
      const fullData = reader.result as string;
      const base64Data = fullData.split(',')[1];
      setSelectedFile({
        data: base64Data,
        mimeType: file.type || 'text/plain',
        name: file.name
      });
      if (file.type.startsWith('image/')) {
        setPreviewUrl(fullData);
      } else {
        setPreviewUrl(null);
      }
    };
    reader.readAsDataURL(file);
  };

  const startReassuringLoading = () => {
    const messages = [t.videoLoadingMsg1, t.videoLoadingMsg2, t.videoLoadingMsg3, t.videoLoadingMsg4];
    let idx = 0;
    setStatus(messages[idx]);
    statusIntervalRef.current = window.setInterval(() => {
      idx = (idx + 1) % messages.length;
      setStatus(messages[idx]);
    }, 6000);
  };

  const stopReassuringLoading = () => {
    if (statusIntervalRef.current) {
      clearInterval(statusIntervalRef.current);
      statusIntervalRef.current = null;
    }
  };

  const handleImagine = async (overridePrompt?: string, isFollowUp = false) => {
    const activePrompt = overridePrompt || (isFollowUp ? followUpPrompt : prompt);
    if (!activePrompt.trim() && !selectedFile && !isFollowUp) return;

    setLoading(true);
    setStreamingStory('');
    if (!isFollowUp) setResult(null);

    try {
      setStatus(t.weaving);
      const history = result?.story || "";
      const { story, sources, neuralPaths } = await imagineScenarioStream(
        activePrompt, 
        history, 
        selectedFile || undefined, 
        language, 
        genMode, 
        undefined,
        (text) => setStreamingStory(text)
      );
      
      setStatus(t.visualizing);
      const imageUrl = await generateVisual(story);
      
      setStatus(t.recording);
      const audioData = await narrateStory(story, language, genMode, dualSpeaker);

      const newResult: ImaginationResult = {
        id: crypto.randomUUID(),
        prompt: activePrompt || selectedFile?.name || "Manifestation",
        story,
        imageUrl: imageUrl || undefined,
        audioData: audioData || undefined,
        sources,
        neuralPaths,
        timestamp: Date.now()
      };

      setResult(newResult);
      onSave(newResult);
      setStreamingStory('');
      if (isFollowUp) setFollowUpPrompt('');
      setPrompt('');
      setSelectedFile(null);
      setPreviewUrl(null);
      if (fileInputRef.current) fileInputRef.current.value = '';
    } catch (error: any) {
      console.error(error);
      alert("Error: The connection was interrupted.");
    } finally {
      setLoading(false);
      setStatus('');
    }
  };

  const handleGenerateVideo = async () => {
    if (!result) return;
    setVideoLoading(true);
    startReassuringLoading();
    try {
      const videoUrl = await generateVideo(result.story, result.imageUrl);
      if (videoUrl) {
        const updatedResult = { ...result, videoUrl };
        setResult(updatedResult);
        onSave(updatedResult);
      }
    } catch (error: any) {
      console.error(error);
      alert("Synthesis failed.");
    } finally {
      setVideoLoading(false);
      stopReassuringLoading();
      setStatus('');
    }
  };

  const playAudio = async () => {
    if (!result?.audioData) return;
    
    if (isPlaying) {
      sourceRef.current?.stop();
      setIsPlaying(false);
      return;
    }

    try {
      if (!audioContextRef.current) {
        audioContextRef.current = new (window.AudioContext || (window as any).webkitAudioContext)();
      }
      
      const ctx = audioContextRef.current;
      const bytes = decodeBase64ToBytes(result.audioData);
      const buffer = await decodeAudioData(bytes, ctx);
      
      const source = ctx.createBufferSource();
      source.buffer = buffer;
      source.connect(ctx.destination);
      source.onended = () => setIsPlaying(false);
      
      sourceRef.current = source;
      source.start();
      setIsPlaying(true);
    } catch (err) {
      console.error("Audio error:", err);
    }
  };

  return (
    <div className="max-w-5xl mx-auto px-4 py-12 md:py-24 space-y-12">
      <header className="text-center space-y-4">
        <h1 className="text-5xl md:text-7xl font-heading font-black tracking-tighter uppercase italic">
          IMAGINE <span className="gradient-text">X</span>
        </h1>
        <p className="text-gray-500 font-light tracking-widest uppercase">
          {t.visionVoiceNarrative}
        </p>
      </header>

      <div className="space-y-8">
        <div className="glass rounded-3xl p-6 md:p-8 space-y-6">
          {previewUrl && (
            <div className="relative aspect-video rounded-2xl overflow-hidden border border-white/10">
               <img src={previewUrl} className="w-full h-full object-cover" alt="Preview" />
               <button onClick={() => { setSelectedFile(null); setPreviewUrl(null); }} className="absolute top-4 right-4 w-10 h-10 rounded-full bg-black/50 text-white flex items-center justify-center hover:bg-red-500 transition-colors">
                 <i className="fa-solid fa-xmark"></i>
               </button>
            </div>
          )}

          <textarea
            value={prompt}
            onChange={(e) => setPrompt(e.target.value)}
            placeholder={t.placeholder}
            className="w-full bg-transparent border-none focus:ring-0 text-white placeholder-gray-700 text-xl md:text-2xl font-light outline-none resize-none min-h-[100px]"
          />
          
          <div className="flex flex-wrap items-center justify-between gap-4 pt-4 border-t border-white/5">
            <div className="flex items-center gap-3">
              <input type="file" ref={fileInputRef} onChange={handleFileChange} className="hidden" accept="image/*,.txt,.pdf" />
              <button
                onClick={() => fileInputRef.current?.click()}
                className={`w-12 h-12 rounded-xl flex items-center justify-center transition-all ${selectedFile ? 'bg-indigo-600 text-white' : 'bg-white/5 text-gray-500 hover:bg-white/10'}`}
              >
                <i className="fa-solid fa-plus"></i>
              </button>
              
              <div className="flex bg-white/5 p-1 rounded-xl">
                 <button onClick={() => setGenMode(GenerationMode.STORY)} className={`px-4 py-2 rounded-lg text-[10px] font-bold uppercase tracking-widest ${genMode === GenerationMode.STORY ? 'bg-indigo-600 text-white' : 'text-gray-500'}`}>Story</button>
                 <button onClick={() => setGenMode(GenerationMode.SONG)} className={`px-4 py-2 rounded-lg text-[10px] font-bold uppercase tracking-widest ${genMode === GenerationMode.SONG ? 'bg-indigo-600 text-white' : 'text-gray-500'}`}>Song</button>
              </div>

              <button onClick={() => setDualSpeaker(!dualSpeaker)} className={`px-4 py-2 rounded-xl text-[10px] font-bold uppercase tracking-widest transition-all ${dualSpeaker ? 'bg-purple-600 text-white' : 'bg-white/5 text-gray-500'}`}>
                {dualSpeaker ? 'Dual Voice' : 'Single Voice'}
              </button>
            </div>

            <button
              disabled={loading}
              onClick={() => handleImagine()}
              className="bg-indigo-600 hover:bg-indigo-500 text-white font-bold h-12 px-8 rounded-xl flex items-center gap-3 transition-all disabled:opacity-50"
            >
              {loading ? <i className="fa-solid fa-spinner animate-spin"></i> : <i className="fa-solid fa-bolt"></i>}
              <span>{t.process}</span>
            </button>
          </div>
        </div>

        {loading && streamingStory && (
          <div className="glass p-8 rounded-3xl border-indigo-500/20 animate-pulse">
             <p className="text-xl text-gray-300 italic">"{streamingStory}..."</p>
          </div>
        )}

        {(loading || videoLoading) && !streamingStory && (
          <div className="flex flex-col items-center py-20 space-y-6">
            <div className="w-12 h-12 border-2 border-indigo-500 border-t-transparent rounded-full animate-spin"></div>
            <p className="text-indigo-400 text-xs font-bold uppercase tracking-[0.3em]">{status}</p>
          </div>
        )}

        {result && !loading && !videoLoading && (
          <div className="page-transition space-y-8 pb-20">
            <div className="relative aspect-video rounded-3xl overflow-hidden shadow-2xl bg-black">
                {result.videoUrl ? (
                    <video src={result.videoUrl} controls autoPlay loop className="w-full h-full object-cover" />
                ) : (
                    <img src={result.imageUrl} alt="Result" className="w-full h-full object-cover" />
                )}
                <div className="absolute bottom-6 right-6">
                  {hasVeoKey ? (
                    <button onClick={handleGenerateVideo} className="bg-white/10 backdrop-blur-md hover:bg-white/20 text-white px-6 py-3 rounded-xl flex items-center gap-2 text-[10px] font-bold uppercase tracking-widest">
                      <i className="fa-solid fa-video"></i> {t.generateVideo}
                    </button>
                  ) : (
                    <button onClick={() => (window as any).aistudio?.openSelectKey()} className="bg-white/10 backdrop-blur-md text-white/50 px-6 py-3 rounded-xl text-[10px] font-bold uppercase tracking-widest">
                      {t.selectKey}
                    </button>
                  )}
                </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              <div className="md:col-span-2 space-y-6">
                <div className="glass p-8 rounded-3xl space-y-6">
                   <div className="flex items-center justify-between">
                      <h3 className="text-indigo-400 text-[10px] font-bold uppercase tracking-[0.3em]">{t.narrative}</h3>
                      <button onClick={playAudio} className={`w-10 h-10 rounded-full flex items-center justify-center transition-all ${isPlaying ? 'bg-indigo-600 text-white' : 'bg-white/5 text-gray-400'}`}>
                        <i className={`fa-solid ${isPlaying ? 'fa-pause' : 'fa-play'}`}></i>
                      </button>
                   </div>
                   <p className="text-xl leading-relaxed text-gray-200">{result.story}</p>
                   
                   <div className="pt-6 border-t border-white/5 flex flex-wrap gap-2">
                     {result.sources.map((src, i) => (
                       <a key={i} href={src.uri} target="_blank" rel="noreferrer" className="text-[10px] bg-white/5 hover:bg-white/10 px-3 py-1.5 rounded-lg text-gray-500 hover:text-white transition-colors">
                         {src.title}
                       </a>
                     ))}
                   </div>
                </div>
              </div>

              <div className="space-y-6">
                 <div className="glass p-6 rounded-3xl space-y-4">
                    <h3 className="text-purple-400 text-[10px] font-bold uppercase tracking-[0.3em]">{t.neuralPaths}</h3>
                    <div className="space-y-2">
                       {result.neuralPaths?.map((path, i) => (
                         <button key={i} onClick={() => handleImagine(path, true)} className="w-full text-left p-4 rounded-xl bg-white/5 hover:bg-indigo-600/20 hover:text-indigo-400 transition-all text-xs text-gray-400 italic">
                           "{path}"
                         </button>
                       ))}
                    </div>
                 </div>

                 <div className="glass p-6 rounded-3xl space-y-4">
                    <input
                      type="text"
                      value={followUpPrompt}
                      onChange={(e) => setFollowUpPrompt(e.target.value)}
                      placeholder={t.continue}
                      className="w-full bg-white/5 border border-white/5 rounded-xl px-4 py-3 text-xs outline-none focus:ring-1 focus:ring-indigo-500"
                    />
                    <button onClick={() => handleImagine(undefined, true)} disabled={loading} className="w-full bg-indigo-600 py-3 rounded-xl font-bold text-xs uppercase tracking-widest active:scale-95 transition-transform">
                      Continue
                    </button>
                 </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default ImagineView;